export const Authorization = "Authorization";
export const X_TENANT_ID = "X-Tenant-Id";
export const X_AUTH_TOKEN_KEY = "X-Auth-Token";
