export const events = {
    user: {
        signUp: "onUserSignUp",
        signIn: "onUserSignIn"
    }
};
