process.env.PORT = "4200";
process.env.NODE_ENV = "test";
process.env.JWT_SECRET = "cannot be empty";
process.env.MAILGUN_API_KEY = "cannot be empty";
process.env.MAILGUN_API_DOMAIN = "cannot be empty";
