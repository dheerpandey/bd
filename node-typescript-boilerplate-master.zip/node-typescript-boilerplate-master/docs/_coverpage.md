# Node TypeScript Boilerplate <small class='versionSpot'></small>

> A boilerplate for your Node TypeScipt enterprise projects.

* Full Support for async/await
* Data Abstraction done Right
* Powered by TypeScript

[GitHub](https://github.com/ofuochi/node-typescript-boilerplate)
[Get Started](#readme.md)