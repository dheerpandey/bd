---
name: Feature Request :gift: 
about: Suggest a new idea or work item for the project.
---

<!--
  Please make sure that you fill out each of the sections below, failing to do so will result in your issue being closed. 
  Remember to, always, always check that the issue does not exist before creating a new one!  https://github.com/ofuochi/node-typescript-boilerplate/issues
-->

## Summary

Please provide an explanation of the feature or work item...