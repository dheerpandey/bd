module.exports = {
    parser: 'babel-eslint',
    extends: ['plugin:prettier/recommended']
};
