export { bookRepository } from './book.repository';
