module.exports = {
    tabWidth: 4,
    singleQuote: true,
    proseWrap: 'always'
};
